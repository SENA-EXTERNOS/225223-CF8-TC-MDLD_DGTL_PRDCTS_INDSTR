function ExecuteScript(strId)
{
  switch (strId)
  {
      case "60nVEVPIQNP":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

